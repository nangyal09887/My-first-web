export interface Comment {
  id: string;
  author: string;
  rating: number; // 1-5 skulls
  text: string;
  timestamp: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  priceBtc: number; // Price in Bitcoin
  priceUsd: number; // Equivalent USD price
  rating: number; // Average skull rating
  category: 'Ghost Suppression' | 'Cursed Alchemy' | 'Nightmare Repellent' | 'Security & Ward' | 'Artifact Care' | 'Astral Defense' | 'Occult Custom';
  imageUrl: string; // Base64 or preset image path
  sellerName: string;
  condition: 'Decaying' | 'Slightly Cursed' | 'Haunted' | 'Eldritch' | 'Freshly Harvested';
  horrorProblemSolved: string; // The problem this product solves
  comments: Comment[];
  isPremium?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
