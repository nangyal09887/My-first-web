import { Product } from './types';

export const CATEGORIES = [
  'All Artifacts',
  'Ghost Suppression',
  'Cursed Alchemy',
  'Nightmare Repellent',
  'Security & Ward',
  'Artifact Care',
  'Astral Defense',
  'Occult Custom'
] as const;

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-poltergeist-muffler',
    title: 'The Poltergeist Muffler 3000',
    description: 'Tired of flying teacups and self-slamming bedroom doors? This tactical dark obsidian emitter generates a reverse-frequency scalar wave that instantly anchors poltergeists to the shadow realm, dampening physical kinetic manipulation up to 500 sq ft. Simply place near the haunting center and toggle active.',
    priceBtc: 0.0035,
    priceUsd: 245,
    rating: 5,
    category: 'Ghost Suppression',
    imageUrl: 'ghost-suppressor',
    sellerName: 'Vek_the_Exorcist',
    condition: 'Freshly Harvested',
    horrorProblemSolved: 'Stops restless poltergeists from throwing kitchen knifes, shaking beds, and slamming doors at 3:00 AM.',
    isPremium: true,
    comments: [
      {
        id: 'c1',
        author: 'HauntedHush',
        rating: 5,
        text: 'Absolute game changer. My cabinets were banging every night. Set it up in the hallway, now they just hum softly instead of flying off their hinges.',
        timestamp: '2 hours ago'
      },
      {
        id: 'c2',
        author: 'SpookyMom',
        rating: 4,
        text: 'Works great but makes my cat stare at the ceiling for hours. Small price to pay for uninterrupted sleep.',
        timestamp: '1 day ago'
      }
    ]
  },
  {
    id: 'prod-blood-bleach',
    title: 'Severed Bond Blood Bleach',
    description: 'Ordinary cleaners won\'t erase the crimson memory of astral feeding. Our chemically treated ash formula dissolves stubborn, spectral blood splatter that ordinary bleach can\'t touch. Infused with holy water distillate and sulfur, it removes phantom odors, ectoplasmic residue, and recurring self-generating stains.',
    priceBtc: 0.0012,
    priceUsd: 84,
    rating: 4,
    category: 'Cursed Alchemy',
    imageUrl: 'blood-bleach',
    sellerName: 'WitchAlchemist_X',
    condition: 'Slightly Cursed',
    horrorProblemSolved: 'Completely dissolves bloodstains and dark matter footprints that keep regenerating at midnight on floors or stairs.',
    comments: [
      {
        id: 'c3',
        author: 'CleanFreakOccult',
        rating: 5,
        text: 'The stain under the rug is finally GONE! Smells like burned matches but it is a miracle formula.',
        timestamp: '4 days ago'
      }
    ]
  },
  {
    id: 'prod-dream-catcher',
    title: 'Dreamcatcher of the Abyss',
    description: 'Standard dreamcatchers are toys. The Obsidian Eye is hand-forged in sulfur mines under a lunar eclipse. It doesn\'t just catch nightmares; it attracts and active-digests the shadow parasites responsible for sleep paralysis. Safe anchor keeps your brain activity grounded during heavy rapid-eye-movement cycles.',
    priceBtc: 0.0021,
    priceUsd: 147,
    rating: 5,
    category: 'Nightmare Repellent',
    imageUrl: 'obsidian-eye',
    sellerName: 'OneiricWarden',
    condition: 'Eldritch',
    horrorProblemSolved: 'Acts as an active defense barrier against Sleep Paralysis shadow figures and parasitic nightmare entities.',
    isPremium: true,
    comments: [
      {
        id: 'c4',
        author: 'RestfulCorpse',
        rating: 5,
        text: 'For the first time in 5 years, the tall man in the fedora did not stand in my corner. Worth every Satoshi.',
        timestamp: '12 hours ago'
      }
    ]
  },
  {
    id: 'prod-mirror-ward',
    title: 'Mirror-Warding Occult Salt-Stick',
    description: 'Avoid unwanted reflective twins from trading places with you. Mirrors are raw portals that leave your physical home accessible to inverse-dwellers. A single rub of this compressed black-salt torch across any reflective surface creates a high-density refractive protection barrier. Ensures your double stays where they belong.',
    priceBtc: 0.0008,
    priceUsd: 56,
    rating: 4,
    category: 'Security & Ward',
    imageUrl: 'mirror-stick',
    sellerName: 'ReflectiveExile',
    condition: 'Decaying',
    horrorProblemSolved: 'Prevents mimic entities or mirrored reflections from moving independently and escaping bathroom portals.',
    comments: [
      {
        id: 'c5',
        author: 'MirrorHater',
        rating: 4,
        text: 'Applied it to my dressing mirror. I saw my reflection try to blink while I was awake, but it got blocked by the salt flare! Scared the hell out of me but it works!',
        timestamp: '3 days ago'
      }
    ]
  },
  {
    id: 'prod-grimoire-cover',
    title: 'The Necronomicon Dust-Cover',
    description: 'Books bound in leather-flesh tend to weep blood, mutter blasphemous chants, or physically chew on neighboring books. Our silver-stitched, lead-insulated seal cover stabilizes chaotic magic, absorbs eldritch radiation, and locks ancient binding spells in place so your spellbooks stay quiet and strictly shut when not in use.',
    priceBtc: 0.0019,
    priceUsd: 133,
    rating: 5,
    category: 'Artifact Care',
    imageUrl: 'grimoire-cover',
    sellerName: 'LibrarianOfUnyieldingShadows',
    condition: 'Haunted',
    horrorProblemSolved: 'Stops cursed grimoires or sentient books from sobbing, reciting hexes, or taking bites out of your shelf.',
    comments: [
      {
        id: 'c6',
        author: 'NecroLover99',
        rating: 5,
        text: 'My skin book has stopped snoring in the middle of the night. Also, it fits like a glove.',
        timestamp: '1 week ago'
      }
    ]
  },
  {
    id: 'prod-soul-anklet',
    title: 'Soul-Anchoring Copper Anklet',
    description: 'Sleepwalkers and astral projection hobbyists run a severe risk of finding their empty physical bodies occupied by transient entities when returning. This heavy-gauge magnetized copper anklet generates a high-attraction harmonic pull to your unique psychic wave, securing your soul tightly to your bones.',
    priceBtc: 0.0028,
    priceUsd: 196,
    rating: 5,
    category: 'Astral Defense',
    imageUrl: 'soul-anklet',
    sellerName: 'AstralGuide_8',
    condition: 'Eldritch',
    horrorProblemSolved: 'Prevents wandering spirits, ghosts, or demons from hijacking your vacant physical body during sleep or astral projection.',
    comments: [
      {
        id: 'c7',
        author: 'DreamDrifter',
        rating: 5,
        text: 'Woke up in my bedroom and immediately locked back into my body. Usually it takes 3 hours of struggle. Wonderful spiritual anchor.',
        timestamp: '2 days ago'
      }
    ]
  }
];
