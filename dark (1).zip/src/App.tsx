import { useState, useEffect } from 'react';
import { Product, CartItem, Comment } from './types';
import { INITIAL_PRODUCTS, CATEGORIES } from './data';
import { spookyAudio } from './components/AudioEngine';
import HorrorHeader from './components/HorrorHeader';
import ProductCard from './components/ProductCard';
import ProductDetailsModal from './components/ProductDetailsModal';
import CartModal from './components/CartModal';
import CheckoutModal from './components/CheckoutModal';
import SellItemModal from './components/SellItemModal';
import { Search, Filter, Skull, Sparkles, SlidersHorizontal, HeartCrack, ChevronUp, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  // State: Core store catalogs
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);

  // State: Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Artifacts');
  const [selectedCondition, setSelectedCondition] = useState<string>('All Conditions');
  const [priceRange, setPriceRange] = useState<number>(0.005); // max btc ceiling

  // State: Modal visual flows
  const [activeDetailsProduct, setActiveDetailsProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isSellOpen, setIsSellOpen] = useState(false);

  // State: Splash / Disclaimer popup (to satisfy browser Audio API interaction)
  const [showSplash, setShowSplash] = useState(true);

  // Load catalogs on mount
  useEffect(() => {
    // 1. Hydraulically load custom products from localStorage
    const cachedProducts = localStorage.getItem('dark_store_products');
    if (cachedProducts) {
      try {
        setProducts(JSON.parse(cachedProducts));
      } catch (e) {
        setProducts(INITIAL_PRODUCTS);
      }
    } else {
      setProducts(INITIAL_PRODUCTS);
      localStorage.setItem('dark_store_products', JSON.stringify(INITIAL_PRODUCTS));
    }

    // 2. Hydraulically load cart from localStorage
    const cachedCart = localStorage.getItem('dark_store_cart');
    if (cachedCart) {
      try {
        setCart(JSON.parse(cachedCart));
      } catch (e) {
        setCart([]);
      }
    }
  }, []);

  // Save changes to localStorage on product updates
  const saveProductsToStorage = (updatedList: Product[]) => {
    setProducts(updatedList);
    localStorage.setItem('dark_store_products', JSON.stringify(updatedList));
  };

  // Keep cart synced to localStorage
  const saveCartToStorage = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem('dark_store_cart', JSON.stringify(updatedCart));
  };

  // --- CART POSSESSIONS CORE ---
  const handleAddToCart = (product: Product) => {
    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      const updated = cart.map(item =>
        item.product.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      saveCartToStorage(updated);
    } else {
      const updated = [...cart, { product, quantity: 1 }];
      saveCartToStorage(updated);
    }
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    const updated = cart.map(item =>
      item.product.id === productId ? { ...item, quantity } : item
    );
    saveCartToStorage(updated);
  };

  const handleRemoveCartItem = (productId: string) => {
    const updated = cart.filter(item => item.product.id !== productId);
    saveCartToStorage(updated);
  };

  const handleClearCart = () => {
    saveCartToStorage([]);
  };

  // --- SELLING / LIST CUSTOM CRATE ---
  const handleAddProduct = (newProduct: Product) => {
    const updated = [newProduct, ...products];
    saveProductsToStorage(updated);
    // Speed up adrenaline
    spookyAudio.playDoomScream();
  };

  // --- WARNING CORRUPTION COMMENTS ADD ---
  const handleAddComment = (productId: string, comment: Comment) => {
    const updated = products.map(prod => {
      if (prod.id === productId) {
        const updatedComments = [comment, ...prod.comments];
        const newProd = { ...prod, comments: updatedComments };
        // If modal matches active details, mirror state
        if (activeDetailsProduct?.id === productId) {
          setActiveDetailsProduct(newProd);
        }
        return newProd;
      }
      return prod;
    });
    saveProductsToStorage(updated);
  };

  // --- SUBTLE DISMISS SPLASH SOUND OPTION ---
  const handleDismissSplash = (enableAudio: boolean) => {
    setShowSplash(false);
    if (enableAudio) {
      spookyAudio.toggleMute(); // activates AudioContext
    }
  };

  // --- FILTER COMBINATORIAL ENGINE ---
  const filteredProducts = products.filter(product => {
    // 1. Category search matches
    const categoryMatches =
      selectedCategory === 'All Artifacts' ||
      product.category === selectedCategory;

    // 2. Condition matches
    const conditionMatches =
      selectedCondition === 'All Conditions' ||
      product.condition === selectedCondition;

    // 3. Search query matches title/description/problem solved
    const combinedTerms = `${product.title} ${product.description} ${product.horrorProblemSolved}`.toLowerCase();
    const searchMatches = combinedTerms.includes(searchQuery.trim().toLowerCase());

    // 4. Price range matches
    const priceMatches = product.priceBtc <= priceRange;

    return categoryMatches && conditionMatches && searchMatches && priceMatches;
  });

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div id="app" className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-[#8b0000] selection:text-white">
      
      {/* 🔮 EERIE CUSTOM CSS FONTS AND SOLID GEOMETRIC LINES */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&family=Space+Grotesk:wght@400;500;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap');
        
        .font-serif {
          font-family: 'Cinzel', Georgia, serif;
        }
        .font-sans {
          font-family: 'Space Grotesk', system-ui, sans-serif;
        }
        .font-mono {
          font-family: 'JetBrains Mono', monospace;
        }
        
        /* Custom solid bold scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
        }
        ::-webkit-scrollbar-track {
          background: #000;
        }
        ::-webkit-scrollbar-thumb {
          background: #8b0000;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #b30000;
        }
      `}</style>

      {/* ⚠️ INTRODUCTORY DISCLOSURE DIALOG FOR AUDIO EMITTING AUTOPLAY */}
      {showSplash && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/98 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#080808] border-2 border-[#8b0000] p-6 sm:p-8 text-center shadow-[0_10px_50px_rgba(0,0,0,0.9)] flex flex-col items-center">
            
            <div className="w-16 h-16 bg-[#8b0000]/10 border border-[#8b0000] flex items-center justify-center mb-6">
              <HeartCrack className="w-8 h-8 text-[#8b0000]" />
            </div>

            <h2 className="font-serif text-4xl font-black text-[#8b0000] mb-2 tracking-tight">
              DARK.
            </h2>
            <p className="font-mono text-[9px] text-neutral-500 uppercase tracking-[0.2em] mb-6">
              THE MERCATUS UMBRA
            </p>

            <p className="font-sans text-xs text-neutral-400 mb-8 leading-relaxed max-w-sm">
              This node operates on a direct cryptographically-secured peer-to-peer registry. Procedural horror synthetic tones and metal vibrations indicate order flow. Approach with sound unleashed.
            </p>

            <div className="flex flex-col gap-3 w-full">
              {/* Option A: Fully custom horizontal audio */}
              <button
                onClick={() => handleDismissSplash(true)}
                className="cursor-pointer bg-[#8b0000] hover:bg-[#a00000] text-white font-mono py-3 text-xs uppercase tracking-[0.25em] transition-all font-black"
              >
                UNLEASH AUDIO
              </button>

              {/* Option B: Mute standard */}
              <button
                onClick={() => handleDismissSplash(false)}
                className="cursor-pointer bg-transparent hover:bg-[#111] border border-[#222] text-neutral-500 hover:text-neutral-300 font-mono py-2.5 text-[9px] uppercase tracking-[0.25em] transition-all"
              >
                Muted Shadow-Path
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRIMARY HEADER CORE */}
      <HorrorHeader 
        cartCount={cartCount} 
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSellModal={() => setIsSellOpen(true)}
      />

      {/* ATMOSPHERIC BANNER (HERO SCREEN) */}
      <section className="relative bg-[#050505] border-b border-[#222] py-14 px-4 sm:px-10 overflow-hidden select-none">
        
        {/* Subtle scanline overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)+50%,rgba(0,0,0,0.25)+50%)] bg-[length:100%_12px] opacity-15 pointer-events-none z-0" />

        <div className="max-w-7xl mx-auto relative z-10 text-center flex flex-col items-center">
          
          <div className="flex items-center gap-1.5 px-3 py-1 border border-[#8b0000] bg-[#8b0000]/5 text-[#8b0000] font-mono text-[8px] uppercase tracking-[0.25em] mb-4">
            <Sparkles className="w-2.5 h-2.5" />
            <span>CRYPTOGRAPHIC CORRUPTION SETTLEMENT</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-6xl font-black text-neutral-100 tracking-tighter max-w-3xl mb-4 leading-none uppercase">
            SOLVING <span className="text-[#8b0000] italic">HAUNTED</span> BLIGHTS WITH CURSED PRODUCTS
          </h2>

          <p className="font-sans text-xs sm:text-sm text-neutral-400 max-w-2xl mb-8 leading-relaxed">
            Every listed item is selected for high functional diagnostics to terminate specific spiritual infections or multi-generational infestations. Every transaction is transacted securely utilizing Peer-to-Peer decentralized Bitcoin ledger entries.
          </p>

          {/* Quick Stats banner */}
          <div className="grid grid-cols-3 gap-3 md:gap-8 max-w-xl w-full border border-[#222] bg-[#0c0c0c] p-4">
            <div className="flex flex-col items-center border-r border-[#222] pr-2">
              <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest leading-none mb-1">Mempool status</span>
              <span className="font-mono text-[10px] text-[#8b0000] font-black tracking-tight">STABLE</span>
            </div>
            <div className="flex flex-col items-center border-r border-[#222] px-2">
              <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest leading-none mb-1">Sealed Artifacts</span>
              <span className="font-mono text-[10px] text-neutral-200 font-bold">{products.length} Relics</span>
            </div>
            <div className="flex flex-col items-center pl-2">
              <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest leading-none mb-1">Exchange network</span>
              <span className="font-mono text-[10px] text-[#f7931a] font-black tracking-tight">BTC LEDGER</span>
            </div>
          </div>

        </div>
      </section>

      {/* PRIMARY CONTROLS & GRID SHELF */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-8 sm:px-10 grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* LEFT COLUMN: FILTERS PANEL AND CONFIG STACK */}
        <div className="lg:col-span-1 flex flex-col gap-6">
          
          <div className="sticky top-24 bg-[#080808] border border-[#222] p-5 flex flex-col gap-6">
            
            {/* Filtering Head */}
            <div className="flex items-center justify-between border-b border-[#222] pb-3">
              <div className="flex items-center gap-2 text-neutral-100 font-serif font-black text-sm uppercase tracking-tight">
                <SlidersHorizontal className="w-4 h-4 text-[#8b0000]" />
                <span>FILTER RELICS</span>
              </div>
              
              <button
                onClick={() => {
                  spookyAudio.playCreepyClick();
                  setSearchQuery('');
                  setSelectedCategory('All Artifacts');
                  setSelectedCondition('All Conditions');
                  setPriceRange(0.005);
                }}
                className="cursor-pointer font-mono text-[8px] text-neutral-500 hover:text-[#8b0000] uppercase tracking-[0.2em] hover:underline flex items-center gap-1 font-bold"
                title="Reset filters"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                <span>PURGE</span>
              </button>
            </div>

            {/* A. SEARCH FIELD */}
            <div className="flex flex-col gap-2">
              <label htmlFor="search-input" className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black">
                OCCULT NOMENCLATURE (SEARCH)
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-neutral-600" />
                <input
                  id="search-input"
                  type="text"
                  placeholder="e.g. glass, skull, tome..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-black border border-[#222] text-neutral-100 placeholder-neutral-700 pl-9 pr-3 py-2 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000] focus:ring-0"
                />
              </div>
            </div>

            {/* B. CATEGORY DROPDOWN */}
            <div className="flex flex-col gap-2">
              <label htmlFor="category-select" className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black">
                CURSED DOMAIN (CATEGORY)
              </label>
              <div className="relative">
                <select
                  id="category-select"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full bg-black border border-[#222] text-neutral-200 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000] cursor-pointer"
                >
                  <option value="All Artifacts">All Artifacts ({products.length})</option>
                  {CATEGORIES.filter(cat => cat !== 'All Artifacts').map((cat) => {
                    const count = products.filter(p => p.category === cat).length;
                    return (
                      <option key={cat} value={cat}>
                        {cat} ({count})
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>

            {/* C. DEGRADATION CONDITION DROPDOWN */}
            <div className="flex flex-col gap-2">
              <label htmlFor="condition-select" className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black">
                DEGRADATION STATE (CONDITION)
              </label>
              <div className="relative">
                <select
                  id="condition-select"
                  value={selectedCondition}
                  onChange={(e) => setSelectedCondition(e.target.value)}
                  className="w-full bg-black border border-[#222] text-neutral-200 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000] cursor-pointer"
                >
                  <option value="All Conditions">All Conditions</option>
                  <option value="Freshly Harvested">Freshly Harvested</option>
                  <option value="Slightly Cursed">Slightly Cursed</option>
                  <option value="Haunted">Haunted</option>
                  <option value="Eldritch">Eldritch</option>
                  <option value="Decaying">Decaying</option>
                </select>
              </div>
            </div>

            {/* D. PRICE SLIDER (BTC) */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black">
                  SOVEREIGN VALUE CEILING
                </label>
                <span className="font-mono text-[10px] text-[#f7931a] font-black">
                  ₿ {priceRange.toFixed(4)}
                </span>
              </div>
              <input
                type="range"
                min="0.0005"
                max="0.0050"
                step="0.0001"
                value={priceRange}
                onChange={(e) => setPriceRange(parseFloat(e.target.value))}
                className="w-full h-1 bg-[#222] rounded-none appearance-none cursor-pointer accent-[#8b0000]"
              />
              <div className="flex justify-between font-mono text-[7.5px] text-neutral-600">
                <span>₿ 0.0005</span>
                <span>₿ 0.0050 Max Limit</span>
              </div>
            </div>

          </div>

        </div>

        {/* RIGHT COLUMN: MAIN PRODUCT GRID FEED */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          
          {/* Active filter tags row */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#080808] border border-[#222] p-4">
            <span className="font-mono text-[10px] text-neutral-400 uppercase tracking-wider">
              RESOLVED ATOMS: <span className="text-[#8b0000] font-black">{filteredProducts.length}</span> SPECTRAL SPECIMENS
            </span>
            
            <div className="flex flex-wrap gap-1.5">
              {selectedCategory !== 'All Artifacts' && (
                <span className="bg-[#8b0000]/10 text-[#8b0000] font-mono text-[8px] border border-[#8b0000]/30 px-2 py-0.5">
                  {selectedCategory}
                </span>
              )}
              {selectedCondition !== 'All Conditions' && (
                <span className="bg-black text-neutral-400 font-mono text-[8px] border border-[#222] px-2 py-0.5">
                  {selectedCondition}
                </span>
              )}
              {searchQuery.trim() !== '' && (
                <span className="bg-black text-neutral-300 font-sans text-[8px] border border-[#8b0000]/40 px-2 py-0.5 max-w-[120px] truncate">
                  "{searchQuery}"
                </span>
              )}
            </div>
          </div>

          {/* Core Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProducts.length === 0 ? (
              <div className="col-span-full py-20 flex flex-col items-center justify-center gap-4 border border-[#222] bg-[#050505]">
                <Skull className="w-10 h-10 text-neutral-800" />
                <h4 className="font-serif text-lg text-neutral-500 italic uppercase">No matching hexes found.</h4>
                <p className="font-sans text-xs text-neutral-600 max-w-xs text-center">
                  Try clearing search inputs or widening your Bitcoin range ceiling.
                </p>
              </div>
            ) : (
              filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onViewDetails={setActiveDetailsProduct}
                />
              ))
            )}
          </div>

        </div>

      </main>

      {/* FOOTER CORE DECLARATIONS */}
      <footer className="w-full bg-[#050505] border-t border-[#222] py-8 px-4 sm:px-10 mt-12 text-center text-neutral-500 text-xs font-mono tracking-wider relative select-none z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex flex-col items-center md:items-start select-none">
            <span className="font-serif text-[#8b0000] text-sm font-black tracking-[0.2em] uppercase">
              DARK.
            </span>
            <span className="text-[8.5px] text-neutral-600 tracking-widest uppercase mt-0.5 block">
              Occult Brokerage Syndicate • Escrow Node 666
            </span>
          </div>

          {/* Quick back to top */}
          <button
            onClick={() => {
              spookyAudio.playCreepyClick();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="cursor-pointer border border-[#222] hover:border-[#8b0000] bg-black text-[9px] px-3.5 py-2.5 text-neutral-500 hover:text-white transition-all flex items-center gap-1.5 uppercase font-bold tracking-widest"
          >
            <ChevronUp className="w-3.5 h-3.5" />
            Top of Shadows
          </button>
          
        </div>
      </footer>

      {/* ================= MODALS STACK (Fully functional interaction layers) ================= */}

      {/* 1. PRODUCT DETAILS DOSSIER MODAL */}
      {activeDetailsProduct && (
        <ProductDetailsModal
          product={activeDetailsProduct}
          onClose={() => {
            spookyAudio.playCreepyClick();
            setActiveDetailsProduct(null);
          }}
          onAddToCart={handleAddToCart}
          onAddComment={handleAddComment}
        />
      )}

      {/* 2. COFFIN CART MODAL */}
      {isCartOpen && (
        <CartModal
          cartItems={cart}
          onClose={() => {
            spookyAudio.playCreepyClick();
            setIsCartOpen(false);
          }}
          onUpdateQuantity={handleUpdateCartQuantity}
          onRemoveItem={handleRemoveCartItem}
          onCheckout={() => {
            setIsCartOpen(false);
            setIsCheckoutOpen(true);
          }}
        />
      )}

      {/* 3. TRANS-ORBITAL CHECKOUT MODAL */}
      {isCheckoutOpen && (
        <CheckoutModal
          cartItems={cart}
          onClose={() => {
            spookyAudio.playCreepyClick();
            setIsCheckoutOpen(false);
          }}
          onClearCart={handleClearCart}
        />
      )}

      {/* 4. SELL ITEM FORGE MODAL */}
      {isSellOpen && (
        <SellItemModal
          onClose={() => {
            spookyAudio.playCreepyClick();
            setIsSellOpen(false);
          }}
          onAddProduct={handleAddProduct}
        />
      )}

    </div>
  );
}
