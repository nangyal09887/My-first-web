import React, { useState } from 'react';
import { Product, Comment } from '../types';
import { spookyAudio } from './AudioEngine';
import { CATEGORIES } from '../data';
import { X, Lock, Flame, Upload, AlertCircle, Info } from 'lucide-react';

interface SellItemModalProps {
  onClose: () => void;
  onAddProduct: (product: Product) => void;
}

const CONDITION_PRESETS = [
  'Freshly Harvested',
  'Slightly Cursed',
  'Haunted',
  'Eldritch',
  'Decaying'
] as const;

export default function SellItemModal({ onClose, onAddProduct }: SellItemModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priceBtc, setPriceBtc] = useState('0.0010');
  const [priceUsd, setPriceUsd] = useState('70');
  const [category, setCategory] = useState<typeof CATEGORIES[number]>('Ghost Suppression');
  const [condition, setCondition] = useState<typeof CONDITION_PRESETS[number]>('Haunted');
  const [horrorProblemSolved, setHorrorProblemSolved] = useState('');
  const [customImage, setCustomImage] = useState('');
  const [customImageName, setCustomImageName] = useState('');
  const [selectedPreset, setSelectedPreset] = useState('default-specimen');
  const [errorWord, setErrorWord] = useState('');

  const handlePriceBtcChange = (val: string) => {
    setPriceBtc(val);
    const num = parseFloat(val);
    if (!isNaN(num)) {
      setPriceUsd(Math.round(num * 70000).toString()); // conversion base
    }
  };

  const handlePriceUsdChange = (val: string) => {
    setPriceUsd(val);
    const num = parseFloat(val);
    if (!isNaN(num)) {
      setPriceBtc((num / 70000).toFixed(6));
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1.5 * 1024 * 1024) {
        setErrorWord("Cursed artifact dimensions are too dense. Keep files under 1.5MB.");
        setTimeout(() => setErrorWord(''), 4000);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        spookyAudio.playCreepyClick();
        setCustomImage(reader.result as string);
        setCustomImageName(file.name);
        setSelectedPreset('uploaded');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    spookyAudio.playClang();

    if (!title.trim() || !description.trim() || !horrorProblemSolved.trim()) {
      setErrorWord('All dark pact inputs must be satisfied before submission.');
      setTimeout(() => setErrorWord(''), 4000);
      return;
    }

    const btcVal = parseFloat(priceBtc);
    const usdVal = parseFloat(priceUsd);

    if (isNaN(btcVal) || btcVal <= 0) {
      setErrorWord('Price coordinates must evaluate above zero.');
      setTimeout(() => setErrorWord(''), 4000);
      return;
    }

    // Determine target imageUrl: uploaded Base64 image OR selection preset
    let targetImage = selectedPreset;
    if (selectedPreset === 'uploaded' && customImage) {
      targetImage = customImage;
    }

    const newProduct: Product = {
      id: 'prod-custom-' + Date.now(),
      title: title.trim(),
      description: description.trim(),
      priceBtc: btcVal,
      priceUsd: isNaN(usdVal) ? Math.round(btcVal * 70000) : usdVal,
      category: category === 'All Artifacts' ? 'Occult Custom' : category,
      condition,
      horrorProblemSolved: horrorProblemSolved.trim(),
      imageUrl: targetImage,
      sellerName: 'Anonymous_Occultist_' + Math.floor(Math.random() * 1000),
      rating: Math.floor(Math.random() * 2) + 4, // 4 or 5 star seed rating
      comments: []
    };

    onAddProduct(newProduct);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/95">
      <div 
        id="sell-modal"
        className="relative w-full max-w-2xl bg-[#080808] border border-[#222] p-6 shadow-[0_10px_50px_rgba(0,0,0,0.95)]"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#222] pb-3 mb-4 bg-black">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-[#8b0000]" />
            <h2 className="font-serif text-lg font-black text-neutral-200 uppercase tracking-tight">
              FORGE ARTIFACT DEAL
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-white p-1 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorWord && (
          <div className="mb-4 p-3 bg-red-950/20 border border-[#8b0000] font-mono text-[10px] text-red-400 flex items-center gap-1.5 uppercase tracking-wider">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorWord}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 max-h-[72vh] overflow-y-auto pr-2">
          
          {/* Main info inputs grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Title / Name */}
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
                RELIC DESIGNATION (ITEM TITLE)
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Medusa Reflection Aegis"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-black border border-[#222] text-neutral-200 placeholder-neutral-800 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000]"
              />
            </div>

            {/* Category selection */}
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
                ARCANE CATEGORY CLASSIFICATION
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="bg-black border border-[#222] text-neutral-350 p-2.5 text-xs rounded-none font-mono focus:outline-none focus:border-[#8b0000] cursor-pointer"
              >
                {CATEGORIES.filter(cat => cat !== 'All Artifacts').map((cat) => (
                  <option key={cat} value={cat} className="bg-[#080808] text-neutral-400">{cat.toUpperCase()}</option>
                ))}
              </select>
            </div>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Condition Selection */}
            <div className="flex flex-col gap-1.5">
              <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
                OCCULT DEGRADATION (CONDITION)
              </label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as any)}
                className="bg-black border border-[#222] text-neutral-350 p-2.5 text-xs rounded-none font-mono focus:outline-none focus:border-[#8b0000] cursor-pointer"
              >
                {CONDITION_PRESETS.map((cond) => (
                  <option key={cond} value={cond} className="bg-[#080808] text-neutral-400">{cond.toUpperCase()}</option>
                ))}
              </select>
            </div>

            {/* Pricing Coordinates */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
                  PRICE (BTC)
                </label>
                <input
                  type="number"
                  step="0.0001"
                  required
                  value={priceBtc}
                  onChange={(e) => handlePriceBtcChange(e.target.value)}
                  className="bg-black border border-[#222] text-[#f7931a] p-2.5 text-xs rounded-none font-mono focus:outline-none focus:border-[#8b0000] select-all font-bold"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
                  EQUIVALENT (USD)
                </label>
                <input
                  type="number"
                  required
                  value={priceUsd}
                  onChange={(e) => handlePriceUsdChange(e.target.value)}
                  className="bg-black border border-[#222] text-neutral-400 p-2.5 text-xs rounded-none font-mono focus:outline-none focus:border-[#8b0000] select-all font-bold"
                />
              </div>
            </div>

          </div>

          {/* PROBLEM SOLVING VALUE PROPOSITION */}
          <div className="flex flex-col gap-1.5 bg-black border border-[#222] p-4">
            <div className="flex items-center gap-1.5 mb-1">
              <Info className="w-3.5 h-3.5 text-[#8b0000]" />
              <label className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black leading-none">
                BANE WARNING & PROBLEM SOLVED (DEMONSTRATE VALUE)
              </label>
            </div>
            <input
              type="text"
              required
              placeholder="e.g. Prevents ghosts from reading your diary or weeping in closet space."
              value={horrorProblemSolved}
              onChange={(e) => setHorrorProblemSolved(e.target.value)}
              className="w-full bg-black border border-[#222] text-red-200 placeholder-neutral-800 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000]"
            />
          </div>

          {/* Description */}
          <div className="flex flex-col gap-1.5">
            <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
              ARCANE EPITAPH & INSTRUCTIONS (DESCRIPTION)
            </label>
            <textarea
              required
              rows={3}
              placeholder="Detail the cursed history, operational safeguards, and spatial warnings..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-black border border-[#222] text-neutral-200 placeholder-neutral-800 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000] resize-none"
            />
          </div>

          {/* IMAGE RESOURCE: Drag/Drop Upload or Creative Preset Selection */}
          <div className="flex flex-col gap-2.5 bg-black border border-[#222] p-4">
            <span className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest font-black">
              ARTIFACT PORTRAIT (PHOTO SOURCE)
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Preset triggers */}
              <div className="flex flex-col gap-1.5">
                <span className="font-mono text-[7px] text-neutral-600 uppercase tracking-widest">Aesthetic Presets</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { key: 'ghost-suppressor', icon: '📟', name: 'Device' },
                    { key: 'blood-bleach', icon: '🧪', name: 'Elixir' },
                    { key: 'obsidian-eye', icon: '👁️', name: 'Talisman' },
                    { key: 'mirror-stick', icon: '🧿', name: 'Sceptre' },
                    { key: 'grimoire-cover', icon: '📖', name: 'Codex' },
                    { key: 'soul-anklet', icon: '⛓️', name: 'Anchor' }
                  ].map((preset) => (
                    <button
                      key={preset.key}
                      type="button"
                      onClick={() => {
                        spookyAudio.playCreepyClick();
                        setSelectedPreset(preset.key);
                      }}
                      className={`cursor-pointer p-2 border flex flex-col items-center justify-center transition-all rounded-none ${
                        selectedPreset === preset.key
                          ? 'border-[#8b0000] bg-[#8b0000]/10 text-white font-bold'
                          : 'border-[#222] bg-[#050505] text-neutral-500 hover:border-neutral-700'
                      }`}
                    >
                      <span className="text-lg">{preset.icon}</span>
                      <span className="text-[7.5px] font-mono uppercase tracking-widest mt-1">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload trigger */}
              <div className="flex flex-col justify-between">
                <div>
                  <span className="font-mono text-[7.5px] text-neutral-600 uppercase tracking-widest block mb-1">Upload True Image Spec</span>
                  <div className="relative border border-dashed border-[#222] hover:border-[#8b0000]/40 p-4 text-center cursor-pointer transition-colors bg-[#050505] flex flex-col items-center justify-center gap-1 rounded-none">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <Upload className="w-5 h-5 text-neutral-600 mb-1" />
                    <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-wider block">
                      {customImageName ? customImageName : "Upload file... (Under 1.5MB)"}
                    </span>
                  </div>
                </div>

                {/* Selected Preset status flag */}
                <div className="text-right mt-2 flex justify-end gap-1.5 items-center font-mono text-[8px] text-neutral-500">
                  <span>Active Image Mode:</span>
                  <span className="text-red-500 font-bold uppercase">{selectedPreset === 'uploaded' ? 'Custom File' : selectedPreset.toUpperCase()}</span>
                </div>
              </div>

            </div>

          </div>

          {/* Secure Blood Covenant Submit button */}
          <button
            type="submit"
            className="cursor-pointer w-full bg-[#8b0000] hover:bg-[#a00000] text-white font-mono py-3 uppercase tracking-[0.2em] font-black"
          >
            <Lock className="w-4 h-4 text-neutral-950 inline mr-1.5" />
            <span>Forge Cursed Contract (List Item)</span>
          </button>

        </form>
      </div>
    </div>
  );
}
