import { CartItem } from '../types';
import { spookyAudio } from './AudioEngine';
import { X, Trash2, ShieldCheck, ShoppingBag, Plus, Minus } from 'lucide-react';

interface CartModalProps {
  cartItems: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export default function CartModal({ cartItems, onClose, onUpdateQuantity, onRemoveItem, onCheckout }: CartModalProps) {
  const totalBtc = cartItems.reduce((acc, item) => acc + (item.product.priceBtc * item.quantity), 0);
  const totalUsd = cartItems.reduce((acc, item) => acc + (item.product.priceUsd * item.quantity), 0);

  const handleUpdateQuantity = (productId: string, current: number, delta: number) => {
    spookyAudio.playCreepyClick();
    const target = current + delta;
    if (target <= 0) {
      onRemoveItem(productId);
    } else {
      onUpdateQuantity(productId, target);
    }
  };

  const handleRemove = (productId: string) => {
    spookyAudio.playClang();
    onRemoveItem(productId);
  };

  const handleCheckoutClick = () => {
    spookyAudio.playDoomScream();
    onCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/95">
      <div 
        id="cart-modal"
        className="relative w-full max-w-lg bg-[#080808] border border-[#222] shadow-[0_10px_50px_rgba(0,0,0,0.95)] flex flex-col"
      >
        {/* Header */}
        <div className="p-4 border-b border-[#222] bg-black flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-[#8b0000]" />
            <h2 className="font-serif text-lg font-black text-neutral-200 uppercase tracking-tight">
              COFFIN OF SOULS
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-white p-1 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 flex-1 overflow-y-auto max-h-[50vh] pr-2 custom-scrollbar">
          {cartItems.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <span className="text-4xl">⚰️</span>
              <p className="font-serif text-sm text-neutral-500 italic text-center uppercase tracking-wide">
                YOUR COFFIN IS VACANT.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {cartItems.map((item) => (
                <div 
                  key={item.product.id}
                  className="bg-[#050505] border border-[#222] p-4 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 border border-[#222] bg-black flex items-center justify-center">
                      <span className="text-xl">
                        {item.product.imageUrl === 'ghost-suppressor' && '📟'}
                        {item.product.imageUrl === 'blood-bleach' && '🧪'}
                        {item.product.imageUrl === 'obsidian-eye' && '👁️'}
                        {item.product.imageUrl === 'mirror-stick' && '🧿'}
                        {item.product.imageUrl === 'grimoire-cover' && '📖'}
                        {item.product.imageUrl === 'soul-anklet' && '⛓️'}
                        {item.product.imageUrl !== 'ghost-suppressor' && 
                         item.product.imageUrl !== 'blood-bleach' && 
                         item.product.imageUrl !== 'obsidian-eye' && 
                         item.product.imageUrl !== 'mirror-stick' && 
                         item.product.imageUrl !== 'grimoire-cover' && 
                         item.product.imageUrl !== 'soul-anklet' && '📦'}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-serif text-xs font-black text-neutral-200 uppercase tracking-tight leading-none mb-1">{item.product.title}</h4>
                      <p className="font-mono text-[8px] text-[#8b0000] uppercase tracking-[0.25em] font-black">{item.product.category}</p>
                      <p className="font-mono text-[10px] text-[#f7931a] font-bold mt-1">₿ {item.product.priceBtc.toFixed(4)}</p>
                    </div>
                  </div>

                  {/* Quantity and Actions */}
                  <div className="flex items-center gap-4">
                    {/* Controls */}
                    <div className="flex items-center border border-[#222] bg-black overflow-hidden select-none">
                      <button
                        onClick={() => handleUpdateQuantity(item.product.id, item.quantity, -1)}
                        className="p-1 px-2.5 text-neutral-500 hover:text-white hover:bg-[#111] cursor-pointer text-xs"
                      >
                        <Minus className="w-2.5 h-2.5" />
                      </button>
                      <span className="font-mono text-xs px-2 text-neutral-200 min-w-[1.5rem] text-center font-bold">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => handleUpdateQuantity(item.product.id, item.quantity, 1)}
                        className="p-1 px-2.5 text-neutral-500 hover:text-white hover:bg-[#111] cursor-pointer text-xs"
                      >
                        <Plus className="w-2.5 h-2.5" />
                      </button>
                    </div>

                    {/* Delete */}
                    <button
                      onClick={() => handleRemove(item.product.id)}
                      className="text-neutral-500 hover:text-[#8b0000] cursor-pointer p-1.5 transition-colors"
                      title="Purge soul"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="p-5 border-t border-[#222] bg-black">
            {/* Summary details */}
            <div className="flex flex-col gap-2.5 mb-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest">Sovereign Bitcoin Sum</span>
                <span className="font-mono text-[#f7931a] font-black text-lg flex items-center gap-1">
                  ₿ {totalBtc.toFixed(4)}
                </span>
              </div>
              <div className="flex items-center justify-between text-neutral-500">
                <span className="font-mono text-[8px] uppercase tracking-widest">Flat Valuation Sum</span>
                <span className="font-mono text-xs">${totalUsd.toLocaleString()} USD</span>
              </div>
            </div>

            {/* Note */}
            <p className="font-sans text-[10px] text-neutral-500 leading-normal italic bg-[#050505] border border-[#222] p-3 mb-4">
              * Peer-to-peer transaction is finalized directly on-chain. Flat references are for analytical calculations only.
            </p>

            {/* Checkout Button */}
            <button
              id="coffin-checkout-btn"
              onClick={handleCheckoutClick}
              className="cursor-pointer w-full bg-[#8b0000] hover:bg-[#a00000] text-white font-mono py-3 uppercase tracking-[0.2em] transition-all font-black"
            >
              <ShieldCheck className="w-4 h-4 inline mr-1.5" />
              Manifest BTC Transaction
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
