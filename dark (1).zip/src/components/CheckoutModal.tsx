import React, { useState, useEffect } from 'react';
import { CartItem } from '../types';
import { spookyAudio } from './AudioEngine';
import { X, CheckCircle2, ShieldAlert, Cpu, Terminal, ArrowRight, Loader2 } from 'lucide-react';

interface CheckoutModalProps {
  cartItems: CartItem[];
  onClose: () => void;
  onClearCart: () => void;
}

const STEPS = [
  'Initiating transaction context mapping...',
  'Connecting BTC Peer-to-Peer network seed nodes...',
  'Generating cryptographically secure shadow escrow payload...',
  'Broadcasting raw transaction bytes to mempool...',
  'Awaiting transaction block consensus mapping...',
  'Validation confirmed. Anchoring dark energy seals...'
];

export default function CheckoutModal({ cartItems, onClose, onClearCart }: CheckoutModalProps) {
  const [walletAddress, setWalletAddress] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [isSuccess, setIsSuccess] = useState(false);
  const [txHash, setTxHash] = useState('');
  const [errorWord, setErrorWord] = useState('');

  const totalBtc = cartItems.reduce((acc, item) => acc + (item.product.priceBtc * item.quantity), 0);
  const darkEscrowAddress = '3DARKx8HaUnTED92qSot0shYsMInERsm666';

  useEffect(() => {
    let interval: any;
    if (isProcessing && currentStepIndex < STEPS.length) {
      interval = setTimeout(() => {
        // Play click sound on log update
        spookyAudio.playCreepyClick();
        setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${STEPS[currentStepIndex]}`]);
        setCurrentStepIndex(prev => prev + 1);
      }, 1500);
    } else if (isProcessing && currentStepIndex === STEPS.length) {
      // Finished
      spookyAudio.playDoomScream();
      setIsProcessing(false);
      setIsSuccess(true);
      setTxHash('0x' + Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''));
    }

    return () => clearTimeout(interval);
  }, [isProcessing, currentStepIndex]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    spookyAudio.playClang();

    if (!walletAddress.trim()) {
      setErrorWord('The dark gods require your sender BTC wallet address to initiate the transaction.');
      setTimeout(() => setErrorWord(''), 4000);
      return;
    }

    // Basic BTC address validation (simulated)
    if (walletAddress.length < 26) {
      setErrorWord('Invalid transaction parameters. Address length must be at least 26 characters.');
      setTimeout(() => setErrorWord(''), 4000);
      return;
    }

    setIsProcessing(true);
    setLogs([`[${new Date().toLocaleTimeString()}] Accessing transaction block indices...`]);
    setCurrentStepIndex(0);
  };

  const handleFinish = () => {
    spookyAudio.playClang();
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/95">
      <div 
        id="checkout-modal"
        className="relative w-full max-w-lg bg-[#080808] border border-[#222] p-6 shadow-[0_10px_50px_rgba(0,0,0,0.95)] overflow-hidden"
      >
        {/* Absolute Background pentagram glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-[#8b0000]/5 filter blur-3xl pointer-events-none" />

        {/* Close Button unless processing */}
        {!isProcessing && !isSuccess && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-neutral-500 hover:text-white p-1 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Dynamic States */}
        {!isProcessing && !isSuccess ? (
          <div>
            {/* Title / Header */}
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xl">🏴‍☠️</span>
              <h2 className="font-serif text-lg font-black text-neutral-100 uppercase tracking-tight">
                BTC ESCROW TRANSFER
              </h2>
            </div>
            <p className="font-sans text-[11px] text-neutral-400 leading-relaxed mb-5 uppercase tracking-wide">
              Transfer Saty Coins block-side to secure ownership of your occult items.
            </p>

            {errorWord && (
              <div className="mb-4 p-3 bg-red-950/20 border border-[#8b0000] font-mono text-[10px] text-red-500 uppercase tracking-wider">
                {errorWord}
              </div>
            )}

            {/* Price overview card */}
            <div className="bg-[#050505] border border-[#222] p-4 mb-5">
              <div className="flex flex-col gap-1 border-b border-[#222] pb-3 mb-3">
                <span className="font-mono text-[8px] text-neutral-400 uppercase tracking-widest leading-none">ESCROW BENEFICIARY HEX</span>
                <span className="font-mono text-[10px] text-neutral-200 break-all select-all font-bold tracking-tight bg-black p-1.5 border border-[#222]">
                  {darkEscrowAddress}
                </span>
              </div>
              <div className="flex justify-between items-baseline pt-1">
                <span className="font-mono text-[8px] text-neutral-400 uppercase tracking-widest font-black">SOVEREIGN ESCROW PAYLOAD</span>
                <span className="font-mono text-base font-black text-[#f7931a]">
                  ₿ {totalBtc.toFixed(4)}
                </span>
              </div>
            </div>

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[8.5px] text-neutral-400 uppercase tracking-widest font-black">
                  YOUR SENDER BTC WALLET ADDRESS
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-[#f7931a] font-mono">₿</span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    className="w-full bg-black border border-[#222] text-neutral-100 placeholder-neutral-800 pl-7 pr-3 py-2.5 text-xs rounded-none font-mono focus:outline-none focus:border-[#8b0000]"
                  />
                </div>
                <p className="font-sans text-[9px] text-neutral-500 leading-normal italic">
                  * Legitimate address formats must be entered to pass consensus validation filters.
                </p>
              </div>

              {/* Confirm submit buttons */}
              <button
                type="submit"
                className="cursor-pointer w-full bg-[#8b0000] hover:bg-[#a00000] text-white font-mono py-3 uppercase tracking-[0.2em] font-black"
              >
                <span>AUTHORIZE CONSENSUS COUPLING</span>
                <ArrowRight className="w-4 h-4 inline ml-1.5" />
              </button>
            </form>
          </div>
        ) : isProcessing ? (
          /* TRANSACTION TIMELINE PROCESSING LOADER */
          <div className="flex flex-col items-center py-6">
            <Loader2 className="w-9 h-9 text-[#8b0000] animate-spin mb-4" />
            <h3 className="font-serif text-base font-black text-neutral-100 uppercase tracking-tight animate-pulse">
              SEALING TRANSACTION BLOCK...
            </h3>
            <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest mb-6">Awaiting miner hash validation</span>

            {/* Terminal output Box */}
            <div className="w-full bg-black border border-[#222] p-4 h-40 overflow-y-auto flex flex-col gap-1.5 font-mono text-[10px] text-neutral-400 select-none">
              <div className="flex items-center gap-1.5 border-b border-[#222] pb-2 mb-2 text-[#8b0000]">
                <Terminal className="w-3.5 h-3.5" />
                <span className="uppercase text-[8px] tracking-[0.2em] font-black">BLOCKCHAIN CONSOLE ENGINE</span>
              </div>
              {logs.map((log, i) => (
                <div key={i} className="text-[#8b0000] flex gap-1.5 items-start leading-relaxed font-mono">
                  <span className="text-neutral-700">❯</span>
                  <span>{log}</span>
                </div>
              ))}
              <div className="text-[#f7931a] mt-1 flex items-center gap-1.5 font-mono">
                <Cpu className="w-3 h-3 animate-pulse" />
                <span className="uppercase text-[9px] tracking-wider font-black">COMPUTING PROOF WEIGHT CONSENSUS...</span>
              </div>
            </div>
          </div>
        ) : (
          /* SUCCESS SCREEN */
          <div className="flex flex-col items-center text-center py-6">
            <div className="w-14 h-14 bg-[#8b0000]/10 border border-[#8b0000] flex items-center justify-center text-[#8b0000] mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="font-serif text-xl font-black text-neutral-100 uppercase tracking-tight mb-2">
              BLOCK ENROLLED
            </h3>
            <p className="font-sans text-xs text-neutral-400 max-w-sm mb-5 leading-relaxed italic">
              Mining network completed proof weight signatures. Your curses have been safely assigned to your sender address. Clear Coffin to finalize exhumation.
            </p>

            {/* Tx details */}
            <div className="w-full bg-[#050505] border border-[#222] p-4 font-mono text-[10px] flex flex-col gap-2 mb-6">
              <div className="flex items-center justify-between">
                <span className="text-neutral-500 uppercase tracking-wider font-bold">Consensus Status:</span>
                <span className="text-emerald-500 font-bold uppercase select-none">CONFIRMED (102 Nodes)</span>
              </div>
              <div className="flex flex-col border-t border-[#222] pt-3 items-start gap-1">
                <span className="text-neutral-500 uppercase tracking-wider text-left font-bold">Consensus Hash Registry:</span>
                <span className="text-neutral-300 break-all text-left bg-black p-1.5 border border-[#222] text-[9px] w-full tracking-tight font-bold">
                  {txHash}
                </span>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="cursor-pointer w-full bg-[#a00000] hover:bg-[#8b0000] text-white font-mono py-2.5 uppercase text-xs tracking-widest font-black"
            >
              Exhumation Complete (Clear Coffin)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
