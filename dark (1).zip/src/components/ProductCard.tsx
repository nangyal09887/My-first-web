import React, { useState } from 'react';
import { Product } from '../types';
import { spookyAudio } from './AudioEngine';
import ProductThumbnail from './ProductThumbnail';
import { Skull, ShieldAlert, ShoppingBag, Terminal } from 'lucide-react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
    // Speed up background horror heartbeat drone as adrenaline rises!
    spookyAudio.setPanicLevel(product.isPremium ? 'terror' : 'anxious');
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    // Calm the heart down
    spookyAudio.setPanicLevel('calm');
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid triggering open details
    spookyAudio.playClang();
    onAddToCart(product);
  };

  const handleViewDetails = () => {
    spookyAudio.playClang();
    onViewDetails(product);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`group relative flex flex-col bg-[#0b0b0b] border border-[#222] overflow-hidden transition-all duration-300 hover:border-[#8b0000] ${
        product.isPremium
          ? 'ring-1 ring-[#8b0000]/30 shadow-[0_4px_30px_rgba(139,0,0,0.15)]'
          : 'shadow-none'
      }`}
    >
      {/* Glitch VHS Scanline Frame Tag */}
      {product.isPremium && (
        <div className="absolute top-2 left-2 z-30 bg-[#8b0000] text-white font-mono text-[8px] font-black uppercase tracking-[0.2em] px-2 py-0.5">
          PREMIUM ITEM
        </div>
      )}

      {/* Product Image Stage */}
      <div className="relative h-48 cursor-pointer overflow-hidden border-b border-[#222]" onClick={handleViewDetails}>
        <ProductThumbnail type={product.imageUrl} isHovered={isHovered} />
        
        {/* Condition sticker */}
        <span className="absolute bottom-2 right-2 bg-black/90 font-mono text-[8px] border border-[#222] text-[#8b0000] px-2 py-0.5 uppercase tracking-wider font-extrabold">
          {product.condition}
        </span>
      </div>

      {/* Card Body */}
      <div className="flex flex-col flex-1 p-5 bg-[#0b0b0b]">
        {/* Category & Rating */}
        <div className="flex items-center justify-between mb-2">
          <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#8b0000] font-black">
            {product.category}
          </span>
          
          {/* Skulls Rating */}
          <div className="flex items-center gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skull
                key={i}
                className={`w-3 h-3 ${
                  i < product.rating
                    ? 'text-[#8b0000] fill-[#8b0000]/30'
                    : 'text-neutral-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Title */}
        <h3 
          onClick={handleViewDetails}
          className="font-serif text-lg font-black text-neutral-100 hover:text-[#8b0000] cursor-pointer tracking-tight mb-2 transition-colors duration-300 uppercase leading-snug"
        >
          {product.title}
        </h3>

        {/* Cursed Description snippet */}
        <p className="font-sans text-xs text-neutral-400 line-clamp-2 leading-relaxed mb-4 italic">
          {product.description}
        </p>

        {/* PROBLEM SOLVED SPEC SHEET - Key user request element! */}
        <div className="mt-auto mb-4 bg-black border border-[#222] p-3">
          <div className="flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-[#8b0000] shrink-0 mt-0.5" />
            <div className="flex flex-col">
              <span className="font-mono text-[8px] uppercase tracking-widest text-neutral-500 font-bold">
                CURES THE PATHOLOGY:
              </span>
              <p className="font-sans text-[11px] text-neutral-300 italic leading-snug">
                {product.horrorProblemSolved}
              </p>
            </div>
          </div>
        </div>

        {/* Pricing Stage (BTC) */}
        <div className="flex items-baseline justify-between mb-4 border-t border-[#222] pt-3">
          <div className="flex flex-col">
            <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest leading-none mb-1">SOVEREIGN BITCOIN</span>
            <span className="font-mono text-base font-black text-[#f7931a] flex items-center gap-0.5">
              ₿ {product.priceBtc.toFixed(4)}
            </span>
          </div>

          <div className="flex flex-col items-end">
            <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest leading-none mb-1">MERCATUS VALUE</span>
            <span className="font-mono text-[11px] text-neutral-400">
              ${product.priceUsd.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Action Buttons: fully working and fully functional */}
        <div className="grid grid-cols-2 gap-2 mt-auto">
          {/* View Details Clang Button */}
          <button
            id={`btn-view-${product.id}`}
            onClick={handleViewDetails}
            className="cursor-pointer border border-[#222] hover:border-[#8b0000] text-neutral-400 hover:text-white hover:bg-[#111] text-[10px] sm:text-xs font-mono py-2.5 uppercase tracking-[0.15em] transition-all duration-300 flex items-center justify-center gap-1.5 font-bold"
          >
            <Terminal className="w-3.5 h-3.5 text-neutral-600 group-hover:text-[#8b0000]" />
            <span>EXAMINE</span>
          </button>

          {/* Add Coffin Button */}
          <button
            id={`btn-add-${product.id}`}
            onClick={handleAddToCart}
            className="cursor-pointer bg-[#8b0000] hover:bg-[#a00000] text-white text-[10px] sm:text-xs font-mono py-2.5 uppercase tracking-[0.15em] transition-all duration-300 flex items-center justify-center gap-1.5 font-black"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>BAG SOUL</span>
          </button>
        </div>

      </div>
    </div>
  );
}
