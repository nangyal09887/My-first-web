import { useState, useEffect } from 'react';
import { Volume2, VolumeX, Ghost, Skull, PlusCircle } from 'lucide-react';
import { spookyAudio } from './AudioEngine';

interface HorrorHeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSellModal: () => void;
}

export default function HorrorHeader({ cartCount, onOpenCart, onOpenSellModal }: HorrorHeaderProps) {
  const [isMuted, setIsMuted] = useState(true);
  const [flicker, setFlicker] = useState(false);

  useEffect(() => {
    // Keep internal local status matching Audio Engine
    setIsMuted(spookyAudio.getMuteStatus());

    // Eerie title flickering timer loop
    const interval = setInterval(() => {
      setFlicker(true);
      setTimeout(() => setFlicker(false), 150);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  const handleMuteToggle = () => {
    const muted = spookyAudio.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      spookyAudio.playEerieWhisper();
    }
  };

  const handleCartClick = () => {
    spookyAudio.playCreepyClick();
    onOpenCart();
  };

  const handleSellClick = () => {
    spookyAudio.playEerieWhisper();
    onOpenSellModal();
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-[#080808] border-b border-[#222] shadow-[0_4px_30px_rgba(0,0,0,0.85)] px-4 py-4 sm:px-10">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Left Side: Audio and Sell */}
        <div className="flex items-center gap-3">
          {/* Mute Controller */}
          <button
            id="sound-toggle-btn"
            onClick={handleMuteToggle}
            className={`cursor-pointer flex items-center gap-1.5 px-3 py-1.5 border font-mono text-[9px] font-bold transition-all duration-300 uppercase tracking-widest ${
              isMuted 
                ? 'border-[#333] text-neutral-500 hover:border-neutral-700 hover:text-neutral-400 bg-transparent' 
                : 'border-[#8b0000] text-[#8b0000] hover:bg-[#8b0000]/10 bg-[#8b0000]/5'
            }`}
            title={isMuted ? "Enable atmospheric horrors & heartbeat" : "Squelch the shadows"}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">
              {isMuted ? 'Muted' : 'Unleashed'}
            </span>
          </button>

          {/* Sell Artifact Button */}
          <button
            id="sell-artifact-btn"
            onClick={handleSellClick}
            className="cursor-pointer flex items-center gap-1.5 border border-[#8b0000] text-[#8b0000] hover:bg-[#8b0000] hover:text-white px-3 py-1.5 transition-all duration-300 font-mono text-[9px] font-bold tracking-[0.2em] uppercase"
          >
            <PlusCircle className="w-3 h-3" />
            <span>List Item</span>
          </button>
        </div>

        {/* Center: Title / Logo from Bold Typography theme */}
        <div className="relative flex flex-col items-center select-none">
          <a href="#" className="flex flex-col items-center group">
            <h1 className="font-serif text-3xl sm:text-5xl font-black tracking-tighter text-[#8b0000] italic leading-none relative">
              DARK.
            </h1>
            <span className="text-[8px] sm:text-[9px] tracking-[0.3em] uppercase opacity-50 font-serif mt-1 block">
              The Mercatus Umbra
            </span>
          </a>
        </div>

        {/* Right Side: Coffin (Cart) */}
        <div className="flex items-center gap-4">
          <button
            id="open-coffin-btn"
            onClick={handleCartClick}
            className="cursor-pointer relative flex items-center gap-2 border border-[#333] hover:border-[#8b0000] bg-[#111] hover:bg-[#8b0000]/10 px-3.5 py-1.5 transition-all duration-300 group shadow-md"
          >
            <Ghost className="w-3.5 h-3.5 text-[#8b0000] group-hover:scale-110 group-hover:animate-bounce transition-transform" />
            
            <span className="hidden sm:inline font-mono text-[10px] text-neutral-400 group-hover:text-[#8b0000] transition-colors uppercase tracking-widest font-semibold">
              Coffin
            </span>

            {/* Pulsing indicator */}
            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#8b0000] text-[9px] font-bold font-mono text-white">
              {cartCount}
            </span>
          </button>
        </div>

      </div>
    </header>
  );
}
