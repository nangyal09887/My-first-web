import React, { useState } from 'react';
import { Product, Comment } from '../types';
import { spookyAudio } from './AudioEngine';
import ProductThumbnail from './ProductThumbnail';
import { X, Skull, Plus, MessageSquare, ShieldAlert, Award, User, Clock } from 'lucide-react';

interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onAddComment: (productId: string, comment: Comment) => void;
}

export default function ProductDetailsModal({ product, onClose, onAddToCart, onAddComment }: ProductDetailsModalProps) {
  const [author, setAuthor] = useState('');
  const [rating, setRating] = useState(5);
  const [commentText, setCommentText] = useState('');
  const [errorWord, setErrorWord] = useState('');

  const handleAddToCart = () => {
    spookyAudio.playDoomScream();
    onAddToCart(product);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    spookyAudio.playClang();

    if (!author.trim() || !commentText.trim()) {
      setErrorWord('The pact demands a scribe name and a warning message.');
      setTimeout(() => setErrorWord(''), 4000);
      return;
    }

    const newComment: Comment = {
      id: 'comment-' + Date.now(),
      author: author.trim(),
      rating,
      text: commentText.trim(),
      timestamp: 'Freshly written'
    };

    onAddComment(product.id, newComment);
    setAuthor('');
    setCommentText('');
    setRating(5);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/95">
      {/* Container */}
      <div 
        id="details-modal"
        className="relative w-full max-w-4xl bg-[#080808] border border-[#222] overflow-hidden flex flex-col md:flex-row shadow-[0_10px_50px_rgba(0,0,0,0.9)]"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-40 bg-black/90 hover:bg-[#8b0000] border border-[#222] hover:border-transparent p-2 text-neutral-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Side: Artwork Media */}
        <div className="w-full md:w-1/2 bg-[#050505] border-r border-[#222] flex flex-col justify-between">
          <div className="flex-1 flex items-center justify-center p-6 pb-2">
            <div className="w-full max-w-sm border border-[#222] overflow-hidden">
              <ProductThumbnail type={product.imageUrl} isHovered={true} />
            </div>
          </div>
          
          {/* Metadata banner */}
          <div className="p-4 bg-black border-t border-[#222]">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-0.5 border-r border-[#222] pr-2">
                <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest">PACT MERCHANT</span>
                <span className="font-sans text-xs text-neutral-300 font-bold uppercase">{product.sellerName}</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest">MORTAL HAZARD LEVEL</span>
                <span className="font-mono text-xs text-[#8b0000] font-black tracking-widest uppercase">
                  {product.condition === 'Eldritch' ? 'FATAL BIOMARK' : product.condition === 'Decaying' ? 'STABLE BLIGHT' : 'SEVERE CORRUPTION'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Informative Body */}
        <div className="w-full md:w-1/2 p-6 flex flex-col h-[85vh] md:h-auto overflow-y-auto max-h-[85vh]">
          {/* Category */}
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-[#8b0000]/10 border border-[#8b0000]/30 text-[#8b0000] font-mono text-[10px] uppercase font-black px-2 py-0.5">
              {product.category}
            </span>
            <span className="text-neutral-500 text-xs font-mono uppercase tracking-wider">• {product.condition}</span>
          </div>

          {/* Title */}
          <h2 className="font-serif text-2xl sm:text-3xl font-black text-neutral-100 tracking-tight uppercase leading-none mb-3">
            {product.title}
          </h2>

          {/* Problem solving details */}
          <div className="bg-black border border-[#222] p-4 mb-4">
            <div className="flex items-start gap-2">
              <ShieldAlert className="w-5 h-5 text-[#8b0000] shrink-0 mt-0.5" />
              <div>
                <h4 className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#8b0000] font-black mb-1">CURES THE INFESTATION:</h4>
                <p className="font-sans text-xs text-neutral-300 italic leading-relaxed">
                  {product.horrorProblemSolved}
                </p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <h4 className="font-mono text-[9px] uppercase tracking-[0.2em] text-neutral-500 mb-1.5 font-bold">ARCANE INVENTORY SUMMARY</h4>
            <p className="font-sans text-xs text-neutral-400 leading-relaxed text-left italic">
              {product.description}
            </p>
          </div>

          {/* Pricing Stage */}
          <div className="flex items-center justify-between p-4 bg-black border border-[#222] mb-6">
            <div>
              <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest block leading-none mb-1.5">BITCOIN PRICE</span>
              <span className="font-mono text-xl font-black text-[#f7931a]">
                ₿ {product.priceBtc.toFixed(4)}
              </span>
            </div>
            <div className="text-right">
              <span className="font-mono text-[8px] text-neutral-500 uppercase tracking-widest block leading-none mb-1.5">USD VALUE</span>
              <span className="font-mono text-sm text-neutral-400">
                ${product.priceUsd.toLocaleString()} USD
              </span>
            </div>
          </div>

          {/* Checkout/Add to Coffin Trigger */}
          <div className="mb-6">
            <button
              onClick={handleAddToCart}
              className="cursor-pointer w-full bg-[#8b0000] hover:bg-[#a00000] text-white font-mono py-3 uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 font-black"
            >
              <Award className="w-4 h-4" />
              <span>SEIZE POSSESSION (ADD COFFIN)</span>
            </button>
          </div>

          {/* PERSISTENT COMMENTS SECTION (Aka Warning Dossier) */}
          <div className="border-t border-[#222] pt-5 mt-4">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-4 h-4 text-[#8b0000]" />
              <h3 className="font-serif text-lg font-black text-neutral-100 uppercase tracking-tight">
                VICTIMS' REGISTRY ({product.comments.length})
              </h3>
            </div>

            {/* Past reviews */}
            <div className="flex flex-col gap-3 mb-6 max-h-48 overflow-y-auto pr-2">
              {product.comments.length === 0 ? (
                <p className="text-neutral-600 text-xs italic font-sans uppercase tracking-wider">No supernatural curses logged yet...</p>
              ) : (
                product.comments.map((comment) => (
                  <div key={comment.id} className="bg-black border border-[#222] p-4 flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3 h-3 text-[#8b0000]" />
                        <span className="font-mono text-[10px] text-neutral-300 font-bold uppercase">{comment.author}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-neutral-600" />
                        <span className="font-mono text-[9px] text-neutral-500 uppercase">{comment.timestamp}</span>
                      </div>
                    </div>
                    <p className="font-sans text-xs text-neutral-400 italic">" {comment.text} "</p>
                    <div className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Skull key={i} className={`w-2.5 h-2.5 ${i < comment.rating ? 'text-[#8b0000]' : 'text-neutral-800'}`} />
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Write feedback form */}
            <form onSubmit={handleCommentSubmit} className="bg-[#050505] border border-[#222] p-5">
              <h4 className="font-mono text-[10px] text-[#8b0000] font-black uppercase tracking-[0.2em] mb-3">
                LOG A SUPERNATURAL WARNING
              </h4>

              {errorWord && (
                <div className="mb-3 p-3 bg-red-950/20 border border-[#8b0000] font-mono text-[10px] text-red-400 uppercase tracking-wider">
                  {errorWord}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 mb-3">
                {/* Author Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest">PEN NAME</label>
                  <input
                    type="text"
                    placeholder="e.g. HexSeeker"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="bg-black border border-[#222] text-neutral-200 placeholder-neutral-800 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000]"
                  />
                </div>

                {/* Rating selection (skulls) */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest">CORRUPTION (SKULLS)</label>
                  <div className="flex items-center gap-1.5 h-9">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setRating(i + 1)}
                        className="p-1 cursor-pointer"
                      >
                         <Skull 
                          className={`w-4 h-4 ${
                            i < rating
                              ? 'text-[#8b0000] fill-[#8b0000]/30'
                              : 'text-neutral-800 hover:text-red-950'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Comment text */}
              <div className="flex flex-col gap-1.5 mb-4">
                <label className="font-mono text-[8.5px] text-neutral-500 uppercase tracking-widest">WARNING MEMORANDUM</label>
                <textarea
                  rows={2}
                  placeholder="Describe mortal casualties or side-effects upon unsealing..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="bg-black border border-[#222] text-neutral-200 placeholder-neutral-800 p-2.5 text-xs rounded-none font-sans focus:outline-none focus:border-[#8b0000] resize-none"
                />
              </div>

              {/* Submit pact */}
              <button
                type="submit"
                className="cursor-pointer w-full bg-black border border-[#8b0000] hover:bg-[#8b0000] text-[#8b0000] hover:text-white font-mono py-2.5 uppercase text-[10px] tracking-[0.2em] transition-all font-black"
              >
                SIGN BLOOD WARNING PACT
              </button>
            </form>

          </div>

        </div>

      </div>
    </div>
  );
}
