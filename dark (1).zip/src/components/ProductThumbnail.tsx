import { Activity, ShieldAlert, Sparkles, AlertTriangle } from 'lucide-react';

interface ProductThumbnailProps {
  type: string;
  isHovered: boolean;
}

export default function ProductThumbnail({ type, isHovered }: ProductThumbnailProps) {
  // If base64 raw data of user uploaded image
  if (type.startsWith('data:') || type.startsWith('http') || type.startsWith('/')) {
    return (
      <div className="relative w-full h-full bg-neutral-950 overflow-hidden flex items-center justify-center border-b border-neutral-900">
        <img
          src={type}
          alt="User Loaded Artifact"
          className={`w-full h-full object-cover transition-all duration-1000 ${
            isHovered ? 'scale-110 filter hue-rotate-15 contrast-125 saturate-150 brightness-75' : 'scale-100'
          }`}
          referrerPolicy="no-referrer"
        />
        {/* Gritty overlay to keep horror atmosphere on custom pictures */}
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-neutral-950/40 to-neutral-950 pointer-events-none" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)+50%,rgba(0,0,0,0.25)+50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%] pointer-events-none opacity-40" />
      </div>
    );
  }

  // Else render high-fidelity creepy stylized vector artwork directly
  return (
    <div className="relative w-full h-48 bg-neutral-950 overflow-hidden flex items-center justify-center border-b border-rose-950/40">
      {/* Background horror particles / flicker grids */}
      <div className={`absolute inset-0 bg-radial-gradient from-rose-950/10 via-neutral-950 to-neutral-950 transition-opacity duration-700 ${isHovered ? 'opacity-100' : 'opacity-70'}`} />
      
      {/* Scanline CRT monitor lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)+50%,rgba(0,0,0,0.3)+50%)] bg-[length:100%_8px] pointer-events-none opacity-30 z-10" />

      {/* Interactive Render */}
      <div className={`relative z-20 transition-all duration-500 transform ${isHovered ? 'scale-105 rotate-1' : 'scale-100'}`}>
        {type === 'ghost-suppressor' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Hologram radiation circle rings */}
            <div className={`absolute inset-0 border border-emerald-950 rounded-full animate-ping opacity-25 duration-3000`} />
            <div className={`absolute w-28 h-28 border border-emerald-900/40 rounded-full transition-all duration-700 ${isHovered ? 'scale-125 border-emerald-500/30' : 'scale-100'}`} />
            
            {/* The main device core */}
            <div className="relative w-16 h-24 bg-neutral-900 border-2 border-neutral-800 rounded-lg flex flex-col items-center justify-between p-2 shadow-2xl shadow-emerald-950/50">
              <div className="w-full h-1 bg-black rounded flex items-center justify-center overflow-hidden">
                <div className={`h-full w-2/3 bg-emerald-500 ${isHovered ? 'w-full animate-pulse' : ''}`} />
              </div>
              
              {/* Spinning ghost cage core inside */}
              <div className="relative w-10 h-10 border border-emerald-600/30 rounded-full flex items-center justify-center bg-black/50 overflow-hidden">
                <Activity className={`w-6 h-6 ${isHovered ? 'text-emerald-400 animate-pulse' : 'text-emerald-700'}`} />
                <div className="absolute inset-0 bg-radial-gradient from-transparent to-black" />
              </div>

              {/* Dials */}
              <div className="flex gap-1.5 justify-center w-full">
                <div className="w-2.5 h-2.5 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center" />
                <div className={`w-2 h-2 rounded-full ${isHovered ? 'bg-red-500 animate-pulse' : 'bg-red-800'}`} />
              </div>
            </div>
            
            {/* Subtle sulfur wisps */}
            <div className="absolute bottom-1 w-full flex justify-center opacity-40">
              <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest bg-emerald-950/40 px-1 border border-emerald-900/60 rounded">SHIELD ACTIVE</span>
            </div>
          </div>
        )}

        {type === 'blood-bleach' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Bleach vapor pool */}
            <div className={`absolute bottom-6 w-16 h-3 rounded-full bg-red-950/60 transition-transform duration-500 ${isHovered ? 'scale-150 bg-red-900/60' : 'scale-100'}`} />
            
            {/* Decocting Flask */}
            <div className="relative w-14 h-24 bg-rose-950/20 border-2 border-rose-900/60 rounded-b-xl rounded-t-lg flex flex-col items-center shadow-[0_0_20px_rgba(220,38,38,0.15)] overflow-hidden">
              {/* Flask cork collar */}
              <div className="w-8 h-4 bg-yellow-950/80 border-b border-rose-900" />
              
              {/* Pulsating horror blood level */}
              <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-red-950 via-red-600 to-rose-500 transition-all duration-1000 ${isHovered ? 'h-3/4' : 'h-1/2'}`}>
                {/* Sludge Bubbles */}
                <span className="absolute top-2 left-2 w-1.5 h-1.5 bg-white/20 rounded-full animate-bounce" />
                <span className="absolute top-3 right-3 w-1 h-1 bg-white/35 rounded-full animate-bounce delay-150" />
                <span className="absolute bottom-2 left-1/2 w-2 h-1 bg-red-400/40 rounded-full" />
              </div>
              
              {/* Glowing label */}
              <div className="absolute top-7 w-8 h-9 border border-rose-900/60 rounded flex items-center justify-center text-rose-500 bg-black/60 z-20">
                <span className="font-mono text-[10px] font-bold">X</span>
              </div>
            </div>
          </div>
        )}

        {type === 'obsidian-eye' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Dark cosmic rift circle */}
            <div className={`absolute w-24 h-24 rounded-full border border-rose-950 bg-neutral-900/70 transition-transform duration-700 ${isHovered ? 'scale-110 border-rose-800 ring-2 ring-rose-900/20' : 'scale-100'}`} />
            
            {/* Sharp obsidian crystalline outer shard */}
            <div className="relative w-20 h-20 rotate-45 border-3 border-neutral-800 bg-neutral-950 shadow-2xl flex items-center justify-center">
              {/* Pulsating red inner eye core */}
              <div className="w-12 h-12 -rotate-45 rounded-full bg-black border border-rose-950 flex items-center justify-center overflow-hidden">
                <div className={`w-8 h-4 rounded-full border-t border-b border-rose-500 bg-rose-950/60 flex items-center justify-center transition-all duration-300 ${isHovered ? 'scale-110 h-7 bg-red-600' : 'scale-100'}`}>
                  {/* Iris slit */}
                  <div className={`w-1.5 h-8 bg-black rounded-full transition-all duration-300 ${isHovered ? 'scale-x-150 bg-neutral-950' : 'scale-x-100'}`} />
                </div>
              </div>
            </div>
          </div>
        )}

        {type === 'mirror-stick' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Ritual pentacle backdrop */}
            <div className={`absolute w-20 h-20 border border-dashed border-purple-950/60 rounded-full ${isHovered ? 'rotate-90 text-purple-600/30' : 'rotate-0 text-purple-950/20'} transition-transform duration-2000`} />
            
            {/* Salt Wand */}
            <div className="relative w-10 h-28 transform -rotate-12 bg-neutral-900 border-2 border-purple-950 rounded shadow-md flex flex-col justify-between p-1">
              <div className="w-full h-8 bg-neutral-950 border border-purple-900/40 rounded flex flex-wrap gap-0.5 justify-center p-0.5 overflow-hidden">
                {/* Embedded purple mineral particles */}
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-sm animate-pulse" />
                <div className="w-1.5 h-1.5 bg-neutral-800 rounded-sm" />
                <div className="w-1.5 h-1.5 bg-purple-600 rounded-sm" />
                <div className="w-1.5 h-1.5 bg-purple-400 rounded-sm animate-pulse" />
              </div>

              {/* Sigil of safety */}
              <div className="flex justify-center flex-1 items-center pb-2">
                <ShieldAlert className={`w-5 h-5 ${isHovered ? 'text-purple-400' : 'text-purple-900'}`} />
              </div>
            </div>
          </div>
        )}

        {type === 'grimoire-cover' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Tome shadow background */}
            <div className="absolute w-28 h-20 bg-black border border-red-950 rounded transform skew-x-3 rotate-6 shadow-2xl" />
            
            {/* Face/Leathery volume */}
            <div className={`relative w-24 h-28 bg-amber-950 border-3 border-amber-900/60 rounded-r-lg shadow-2xl p-2 flex flex-col justify-between transition-transform duration-500 ${isHovered ? '-translate-y-1' : ''}`}>
              {/* Spooky spine ridges */}
              <div className="absolute left-0 top-1 bottom-1 w-2 bg-neutral-950 rounded-r-sm" />
              
              {/* Stitched skin scars on cover */}
              <div className="pl-2 flex flex-col gap-2 opacity-60">
                <div className="w-full h-[1px] bg-red-950/80 relative">
                  <span className="absolute -top-1 left-3 text-[5px] text-red-700">|||</span>
                  <span className="absolute -top-1 left-10 text-[5px] text-red-700">|||</span>
                </div>
                <div className="w-2/3 h-[1px] bg-red-950/80 relative ml-auto">
                  <span className="absolute -top-1 left-4 text-[5px] text-red-700">||</span>
                </div>
              </div>

              {/* Forbidden symbol / lock clasp */}
              <div className="flex justify-center p-1">
                <div className={`w-8 h-8 rounded-full border border-red-950 flex items-center justify-center transition-colors duration-500 ${isHovered ? 'bg-red-950 border-red-600 text-red-500' : 'bg-black text-neutral-600'}`}>
                  <span className="font-mono text-xs text-center">👁</span>
                </div>
              </div>

              {/* Creepy metal corners */}
              <div className="absolute bottom-1 right-1 w-2 h-2 border-r-2 border-b-2 border-neutral-700" />
              <div className="absolute top-1 right-1 w-2 h-2 border-r-2 border-t-2 border-neutral-700" />
            </div>
          </div>
        )}

        {type === 'soul-anklet' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Blue soul nebula swirl */}
            <div className="absolute w-28 h-28 border border-dashed border-sky-950 rounded-full animate-spin duration-10000" />
            <div className={`absolute w-24 h-24 rounded-full bg-radial-gradient from-sky-950/25 to-transparent filter blur-md transition-all duration-700 ${isHovered ? 'scale-120 opacity-100' : 'scale-100 opacity-60'}`} />
            
            {/* Intertwined iron ring structure */}
            <div className="relative w-20 h-20 rounded-full border-8 border-neutral-800 shadow-2xl flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-neutral-600/30" />
              
              {/* Sparkle energy node */}
              <div className="relative z-10 flex flex-col items-center">
                <Sparkles className={`w-6 h-6 transition-all duration-500 ${isHovered ? 'text-sky-300 animate-pulse' : 'text-sky-800'}`} />
                <span className="text-[7px] font-mono text-sky-500 tracking-wider">HARMONIC</span>
              </div>
            </div>
          </div>
        )}

        {/* Fallback general uploaded items */}
        {type !== 'ghost-suppressor' && 
         type !== 'blood-bleach' && 
         type !== 'obsidian-eye' && 
         type !== 'mirror-stick' && 
         type !== 'grimoire-cover' && 
         type !== 'soul-anklet' && (
          <div className="relative w-36 h-36 flex items-center justify-center">
            <div className={`absolute w-24 h-24 rounded border border-rose-950 transition-all duration-500 bg-neutral-900/40 pb-1 ${isHovered ? 'rotate-6 border-rose-700 bg-neutral-900/60' : 'rotate-0'}`} />
            <div className="relative w-20 h-20 bg-neutral-950 border-2 border-dashed border-rose-900/60 rounded flex flex-col items-center justify-center gap-1.5 p-2 text-rose-800 hover:text-rose-500">
              <AlertTriangle className={`w-7 h-7 ${isHovered ? 'text-rose-500 animate-bounce' : 'text-rose-800'}`} />
              <span className="text-[7px] font-mono text-center leading-tight tracking-widest text-neutral-500 uppercase">CLASSIFIED SPECIMEN</span>
            </div>
          </div>
         )}
      </div>
    </div>
  );
}
