class AudioEngine {
  private ctx: AudioContext | null = null;
  private droneOsc: OscillatorNode | null = null;
  private droneGain: GainNode | null = null;
  private heartbeatInterval: any = null;
  private isMuted: boolean = true;
  private pulseRate: number = 800; // ms between beats
  private panicLevel: 'calm' | 'anxious' | 'terror' = 'calm';

  constructor() {
    // Lazy initialisation on first interaction
  }

  private init() {
    if (this.ctx) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      this.ctx = new AudioContextClass();
    } catch (e) {
      console.error("AudioContext initialization failed", e);
    }
  }

  public toggleMute() {
    this.isMuted = !this.isMuted;
    if (!this.isMuted) {
      this.init();
      if (this.ctx?.state === 'suspended') {
        this.ctx.resume();
      }
      this.startDrone();
      this.startHeartbeat();
    } else {
      this.stopDrone();
      this.stopHeartbeat();
    }
    return this.isMuted;
  }

  public getMuteStatus() {
    return this.isMuted;
  }

  public setPanicLevel(level: 'calm' | 'anxious' | 'terror') {
    this.panicLevel = level;
    if (level === 'calm') {
      this.pulseRate = 1200; // Slow sleep heartbeat
    } else if (level === 'anxious') {
      this.pulseRate = 700; // Steady scary heartbeat
    } else if (level === 'terror') {
      this.pulseRate = 400; // Fast adrenaline heartbeat
    }

    if (!this.isMuted) {
      this.stopHeartbeat();
      this.startHeartbeat();
      this.adjustDroneFrequency();
    }
  }

  private adjustDroneFrequency() {
    if (!this.ctx || !this.droneOsc || this.isMuted) return;
    const now = this.ctx.currentTime;
    let freq = 60;
    if (this.panicLevel === 'anxious') freq = 45;
    if (this.panicLevel === 'terror') freq = 35;
    this.droneOsc.frequency.setValueAtTime(freq, now);
  }

  private startDrone() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    try {
      this.stopDrone();

      this.droneOsc = this.ctx.createOscillator();
      this.droneGain = this.ctx.createGain();

      // Detuned sawtooth drone for creepy hum
      this.droneOsc.type = 'sawtooth';
      
      const freq = this.panicLevel === 'calm' ? 60 : (this.panicLevel === 'anxious' ? 45 : 35);
      this.droneOsc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      
      this.droneGain.gain.setValueAtTime(0.015, this.ctx.currentTime); // very low hum

      // Low-pass filter for ominous rumble
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(120, this.ctx.currentTime);

      this.droneOsc.connect(filter);
      filter.connect(this.droneGain);
      this.droneGain.connect(this.ctx.destination);

      this.droneOsc.start();
    } catch (e) {
      console.error(e);
    }
  }

  private stopDrone() {
    try {
      if (this.droneOsc) {
        this.droneOsc.stop();
        this.droneOsc.disconnect();
        this.droneOsc = null;
      }
      if (this.droneGain) {
        this.droneGain.disconnect();
        this.droneGain = null;
      }
    } catch (e) {}
  }

  private startHeartbeat() {
    if (!this.ctx || this.isMuted) return;
    this.stopHeartbeat();

    this.heartbeatInterval = setInterval(() => {
      this.playHeartbeatSound();
    }, this.pulseRate);
  }

  private stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private playHeartbeatSound() {
    if (!this.ctx || this.isMuted) return;
    try {
      const now = this.ctx.currentTime;

      // Double thump: pump (high) then thump (low)
      
      // 1. First beat
      this.pulseThump(now, 55, 0.4);
      
      // 2. Second beat (slightly delayed and lower pitched)
      this.pulseThump(now + 0.15, 45, 0.35);

    } catch (e) {}
  }

  private pulseThump(time: number, startFreq: number, intensity: number) {
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, time);
    // Exponential pitch slide down for deep heavy impact
    osc.frequency.exponentialRampToValueAtTime(10, time + 0.2);

    gain.gain.setValueAtTime(0.02 * intensity, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  // --- SOUND FX ---

  public playClang() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    try {
      const now = this.ctx.currentTime;
      // Synthesized heavy metallic hit
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.8);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

      const delay = this.ctx.createDelay();
      delay.delayTime.setValueAtTime(0.05, now);

      const delayGain = this.ctx.createGain();
      delayGain.gain.setValueAtTime(0.06, now);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      // Simple eerie feedback
      osc.connect(delay);
      delay.connect(delayGain);
      delayGain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.9);
    } catch (e) {}
  }

  public playCreepyClick() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(90, now);
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.08);

      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.1);
    } catch (e) {}
  }

  public playEerieWhisper() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    try {
      const now = this.ctx.currentTime;
      const bufferSize = this.ctx.sampleRate * 1.5; // 1.5 seconds
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      
      // Generate creepy wind/white noise with custom wave filter
      let lastVal = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Lowpass filtering approximation for ghostly wind
        data[i] = 0.9 * lastVal + 0.1 * white;
        lastVal = data[i];
        
        // Tremolo LFO amplitude modulation
        const mod = Math.sin(2 * Math.PI * 6 * (i / this.ctx.sampleRate)); // 6Hz shudder
        data[i] *= (mod * 0.4 + 0.6) * Math.sin(Math.PI * (i / bufferSize)); // fade in/out envelope
      }

      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'peaking';
      filter.frequency.setValueAtTime(800, now);
      filter.Q.setValueAtTime(5, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.09, now);

      noiseNode.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noiseNode.start(now);
      noiseNode.stop(now + 1.5);
    } catch (e) {}
  }

  public playDoomScream() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    try {
      const now = this.ctx.currentTime;
      // High pitch metal frequency
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(420, now);
      osc1.frequency.linearRampToValueAtTime(230, now + 1.2);

      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(440, now); // Detuned for discordant ring
      osc2.frequency.linearRampToValueAtTime(245, now + 1.2);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.06, now + 0.1); // Quick attack
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

      // Low-pass sweeping filtering to give 'closing throat' choke
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1000, now);
      filter.frequency.exponentialRampToValueAtTime(400, now + 1.2);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.25);
      osc2.stop(now + 1.25);
    } catch (e) {}
  }
}

export const spookyAudio = new AudioEngine();
